#include "konfersi.h"
#include <iostream>

using namespace std;

Konfersi::Konfersi()
{
    int sasa;
    char dede = int(sasa);
}
