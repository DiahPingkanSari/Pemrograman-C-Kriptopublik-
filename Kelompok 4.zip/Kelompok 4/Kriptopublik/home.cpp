#include "home.h"
#include "ui_home.h"

Home::Home(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Home)
{
    ui->setupUi(this);
}

Home::~Home()
{
    delete ui;
}


void Home::on_btn_pengirim_clicked()
{
    DIALOG_2 = new Dialog_2(this);
    DIALOG_2->show();
}

void Home::on_btn_penerima_clicked()
{
    //hide();
    DIALOG_3 = new Dialog_3(this);
    DIALOG_3->show();
}
